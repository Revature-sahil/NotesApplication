package com.example.notesapplicationroomdatabase

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface NotesDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert (note: Note)

    @Update
    fun update (note: Note)

    @Delete
    fun delete (note: Note)

    @Query ("Select * from notesTable order by id ASC")
    fun getAllNotes() : LiveData<List<Note>>

//    @Query("SELECT * FROM notesTable WHERE tittle LIKE :query OR description LIKE:query")
//    fun searchNote(query: String?): LiveData<List<Note>>

}