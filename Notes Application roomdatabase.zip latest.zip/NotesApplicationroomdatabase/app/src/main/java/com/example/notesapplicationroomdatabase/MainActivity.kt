package com.example.notesapplicationroomdatabase

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.MenuItem
import android.widget.SearchView
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(), NoteClickDeleteInterface, NoteClickInterface {
    lateinit var notesRV: RecyclerView
    lateinit var addFAB: FloatingActionButton
    lateinit var ViewModel: NoteViewModel
//    lateinit var searchView: SearchView.OnQueryTextListener
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)




    // for loading
    val loading = LoadingDialog(this)
    loading.startLoading()
    val handler = Handler()
    handler.postDelayed(object :Runnable{
        override fun run() {
            loading.isDismiss()
        }

    },2000)


        notesRV = findViewById(R.id.idRVNotes)
        addFAB = findViewById(R.id.idFABAddNote)
//        searchView = findViewById(R.id.menu_search)
        notesRV.layoutManager = LinearLayoutManager(this)

        val noteRVAdapter = NoteRVAdapter(this, this, this)
        notesRV.adapter = noteRVAdapter
        ViewModel = ViewModelProvider(
            this, ViewModelProvider.AndroidViewModelFactory
                .getInstance(application)
        )
            .get(NoteViewModel::class.java)
        ViewModel.allNotes.observe(this, Observer { list ->
            list?.let {
                noteRVAdapter.updateList(it)
            }
        })

        addFAB.setOnClickListener {
            val intent = Intent(this@MainActivity, AddEditNoteActivity::class.java)
            startActivity(intent)
//            this.finish()
        }

    }

    override fun onDeleteIconClick(note: Note) {
        ViewModel.deleteNote(note)
        Toast.makeText(this, "${note.noteTittle} Deleted", Toast.LENGTH_LONG).show()
    }

    override fun onNoteClick(note: Note) {
        val intent = Intent(this@MainActivity, AddEditNoteActivity::class.java)
        intent.putExtra("noteType", "Edit")
        intent.putExtra("noteTitle", note.noteTittle)
        intent.putExtra("noteDescription", note.noteDescription)
        intent.putExtra("noteID", note.id)
        startActivity(intent)
        this.finish()

    }

//    fun onQueryTextSubmit(query: String?): Boolean {
////        if (query != null) {
////            searchNote(query)
////        }
//        return false
//    }

//    fun onQueryTextChange(newText: String?): Boolean {
//
//        if (newText != null) {
//            searchNote(newText)
//        }
//        return true
//    }

//    private fun searchNote(query: String?) {
//        val searchQuery = "%$query%"
//        notesRV.searchNote(searchQuery).observe(
//            this, { list ->
//                notesRV.differ.submitList(list)
//            }
//        )
//    }

//    override fun onDestroy() {
//        super.onDestroy()
//        _binding = null
//    }




}